from Pages.BasePage import BasePage


class OpenWidow(BasePage):
    def test_login_valid(self):
        pass
