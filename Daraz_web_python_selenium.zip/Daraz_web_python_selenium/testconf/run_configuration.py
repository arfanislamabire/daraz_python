# Run configuration
# class RunConfiguration(object):

# system configuration

# For headless run "True" and
headless = False

# For linux OS "True" and for windows "False"
linux = True
# Project configuration
# Portal selection. For staging portal "True" and for live portal "False"
dev_portal = False

